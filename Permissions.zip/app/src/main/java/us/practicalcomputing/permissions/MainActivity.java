// Module Name/Title - Permissions.java - Class for requesting android permissions from the user
// Last Modification Date - March 21, 2017

package us.practicalcomputing.permissions;

import android.app.Activity;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Toast;

import java.util.HashMap;

import static android.Manifest.permission.ACCESS_FINE_LOCATION;
import static android.Manifest.permission.READ_PHONE_STATE;
import static android.Manifest.permission.WRITE_EXTERNAL_STORAGE;

public class MainActivity extends Activity {

	static private final String TAG = "MainActivity: ";
	static private final int PERMISSIONS = 1;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);

//	    If Android system level is Marshmallow or beyond, display the Security Permissions screen
		if (android.os.Build.VERSION.SDK_INT > Build.VERSION_CODES.LOLLIPOP) {
			HashMap<String, String> why = setReasonsWhy();
			Intent intent = new Intent(this, Permissions.class);
			intent.putExtra("Reasons", why);
			startActivityForResult(intent, PERMISSIONS);
		}   // End of if Build.VERSION clause

	}


//  Method to initialize the reasons why we need permissions
	private HashMap<String, String> setReasonsWhy() {

		HashMap<String, String> why = new HashMap<>();

		why.put(ACCESS_FINE_LOCATION,
			"GPS services are used for selecting your performance location and " +
				"for displaying a google map to a performance location");
		why.put(WRITE_EXTERNAL_STORAGE,
			"Access to external storage is needed to play music, play karaoke, " +
				"backup your database, and show app documentation via Adobe PDF Reader");
		why.put(READ_PHONE_STATE,
			"Access to your phone state is needed to avoid playing music during a telephone call");

		return why;
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.menu_main, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// Handle action bar item clicks here. The action bar will
		// automatically handle clicks on the Home/Up button, so long
		// as you specify a parent activity in AndroidManifest.xml.
		int id = item.getItemId();

		//noinspection SimplifiableIfStatement
		if (id == R.id.action_settings) {
			return true;
		}

		return super.onOptionsItemSelected(item);
	}


	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		super.onActivityResult(requestCode, resultCode, data);

		Log.d(TAG, "onActivityResult method started - requestCode=" + requestCode +
			"   resultCode=" + resultCode + "   data=" + data);

		String msg = "We got a strange result code";

		if (resultCode == RESULT_OK) {
			msg = "Thanks for your trust - We will now continue";
		}   // End of if RESULT_OK clause

		else if  (resultCode == RESULT_CANCELED) {
			@SuppressWarnings("unchecked")
			HashMap<String, Integer> m_Permissions = (HashMap) data.getSerializableExtra("Denied");
			msg = "You have chosen to deny permission for -\n";
			for (String key : m_Permissions.keySet()) {
				msg += key + "\n";
			}   // End of while hasNext loop
		}   // End of else if clause

		Toast toast = Toast.makeText(this, msg, Toast.LENGTH_LONG);
		toast.show();
//		toast.show();
//		toast.show();
//		toast.show();

		finish();
	}

}
