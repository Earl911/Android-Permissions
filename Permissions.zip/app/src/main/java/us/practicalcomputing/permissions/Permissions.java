// Module Name/Title - Permissions.java - Class for requesting android permissions from the user
// Last Modification Date - March 21, 2017

package us.practicalcomputing.permissions;

import android.annotation.TargetApi;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.util.Log;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

import static android.content.ContentValues.TAG;

@TargetApi(23)
public class Permissions extends Activity {

	static final private int REQUEST_CODE_ASK_MULTIPLE_PERMISSIONS = 124;
	static final private int REQUEST_CODE_REASK_MULTIPLE_PERMISSIONS = 125;

	final private HashMap<String, Integer> m_Permissions = new HashMap<>();
	private Map<String, String> m_Why = null;


	@Override
	protected void onCreate(Bundle savedInstanceState) {

		super.onCreate(savedInstanceState);

		setContentView(R.layout.activity_permissions);

//		Get the reasons why permissions are needed from the caller's intent
		Intent intent = this.getIntent();
		Object why =  intent.getSerializableExtra("Reasons");
		try {
			//noinspection unchecked
			m_Why = (HashMap<String, String>) why;
		}
		catch (IllegalArgumentException e) {
			throw new IllegalArgumentException("Reasons why is not a HashMap<String, String>");
		}
//      Get android manifest permissions
		getManifestPermissions();

//      Remove any previously granted permissions from permission need list
		checkForPermissions();

//      Ask user, through Android's new mechanism for permissions
		askForPermissions();
	}


//  Method to acquire permissions from android manifest
	private void getManifestPermissions() {

		final Intent mainIntent = new Intent(Intent.ACTION_MAIN, null);
		mainIntent.addCategory(Intent.CATEGORY_LAUNCHER);
		final PackageManager pm = getPackageManager();
		int i;
		PackageInfo packageInfo = null;

		try {
			packageInfo = pm.getPackageInfo(getApplicationContext().getPackageName(),
				PackageManager.GET_PERMISSIONS);
		}   // End of try block
		catch (PackageManager.NameNotFoundException e) {
			Log.e(TAG, "getManifestPermissions - Name not found exception - " + e);
		}   // End of catch block

//      If we found the manifest permissions, save them in permissions table
		if (packageInfo != null) {
			String[] requestedPermissions = packageInfo.requestedPermissions;
			for (i = 0; i < requestedPermissions.length; i++) {
				int result = checkCallingPermission(requestedPermissions[i]);
				Log.d(TAG, "getManifestPermissions - manifest permission " + (i + 1) +
					" '" + requestedPermissions[i] + "' - result=" + result);
				m_Permissions.put(requestedPermissions[i], PackageManager.PERMISSION_DENIED);
			}   // End of for i loop
		}   // End of if packageInfo clause

	}

//  Method to remove any previously granted permissions from needed list
	private void checkForPermissions() {

		int grantResults = PackageManager.PERMISSION_DENIED;

//		Loop through permission map and remove any permissions we already have granted
		Iterator it = m_Permissions.entrySet().iterator();
		while (it.hasNext()) {
			Map.Entry pair = (Map.Entry)it.next();

			if (android.os.Build.VERSION.SDK_INT > Build.VERSION_CODES.LOLLIPOP)
				grantResults = checkSelfPermission((String) pair.getKey());

			if (grantResults == PackageManager.PERMISSION_GRANTED)
				it.remove();
		}	// End of while loop
	}


//  Method to ask user to grant permission
	private void askForPermissions() {

		if (m_Permissions.size() > 0) {
			Set keySet = m_Permissions.keySet();
			String[] keys = (String[]) keySet.toArray(new String[keySet.size()]);

			if (android.os.Build.VERSION.SDK_INT > Build.VERSION_CODES.LOLLIPOP)
				requestPermissions(keys, REQUEST_CODE_ASK_MULTIPLE_PERMISSIONS);
		}
	}


//  Method to interpret user's responses. When ALL the permission have a positive or negative result,
//  the result will be sent to this callback method.

//  Note that this method may be entered recursively -

//      Once initial entry with the REQUEST_CODE_ASK_MULTIPLE_PERMISSIONS request code after the
//      askForPermissions method invokes the Android mechanism.

//      Second entry with the REQUEST_CODE_REASK_MULTIPLE_PERMISSIONS request code after
//      this method builds a reason why permissions are needed and makes a second request

	@Override
	public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions,
	            @NonNull int[] grantResults) {

		int i;

//		Get the results for each permission entry in hash map
		for (i = 0; i < permissions.length; i++) {
			String key = permissions[i];

//			If hash map contains key process it; otherwise ignore
			if (m_Permissions.containsKey(key)) {

//				If permission was granted, remove it from hash map
				if ((grantResults[i] == PackageManager.PERMISSION_GRANTED))
					m_Permissions.remove(key);
			}    // End of if containsKey clause
		}   // End of for HashMap loop

		switch (requestCode) {

//          Initial entry case from askFrPermissions method and Android's mechanism
			case REQUEST_CODE_ASK_MULTIPLE_PERMISSIONS:

				String message, key;
				Iterator iter;

//          If permission hash map is not empty, one or more permissions was denied
				message = "You need to grant access to - ";
				if (m_Permissions.size() > 0) {

//                  Build a list of permissions still needed
					iter = m_Permissions.keySet().iterator();
					while (iter.hasNext()) {
						key = (String) iter.next();
						message = message + ", " + key;
					}   // End of while hasNext loop

//                  Build a list of reasons why they are needed
					iter = m_Permissions.keySet().iterator();
					while (iter.hasNext()) {
						key = (String) iter.next();
						String why = m_Why.get(key);
						if (why != null)
							message = message + "\n\n" + why;
					}   // End of while hasNext loop

//                  Ask user to reconsider their judgement - Show the reasons why. Once user
//                  clicks on the message, we invoke Android's permission mechanism
//                  a second time and cause a recursion to this method with the
//                  REQUEST_CODE_REASK_MULTIPLE_PERMISSIONS request code
					showMessageOKCancel(message, new DialogInterface.OnClickListener() {

						public void onClick(DialogInterface dialog, int which) {
							requestPermissions(
								m_Permissions.keySet().toArray(
									new String[m_Permissions.size()]),
								REQUEST_CODE_REASK_MULTIPLE_PERMISSIONS);
						}
					});
				}   // End of m_Permissions.size clause

				else {
					setResult(Activity.RESULT_OK);
					finish();
				}   // End of else clause

				break;

//          After user reconsiders, we get a recursion entry to this case
			case REQUEST_CODE_REASK_MULTIPLE_PERMISSIONS:
				Intent intent = new Intent();
				if (m_Permissions.size() == 0)
					setResult(Activity.RESULT_OK);

				else if (m_Permissions.size() > 0) {
					intent.putExtra("Denied", m_Permissions);
					setResult(Activity.RESULT_CANCELED, intent);
				}   // End of m_Permissions.size clause

				finish();
				break;

			default:
				super.onRequestPermissionsResult(requestCode, permissions, grantResults);
		}   // End of switch block
	}

//  Method to display why permission needed message
	private void showMessageOKCancel(String message, DialogInterface.OnClickListener okListener) {
		new AlertDialog.Builder(this)
			.setMessage(message)
			.setPositiveButton("OK", okListener)
			.setNegativeButton("Cancel", null)
			.create()
			.show();
	}

}   // End of Permissions class
